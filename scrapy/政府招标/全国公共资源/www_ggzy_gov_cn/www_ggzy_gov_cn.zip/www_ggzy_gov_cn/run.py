# -*- coding: utf-8 -*-
# @Date    : 2022-11-07 17:05
# @Author  : chenxuepeng
from scrapy import cmdline

cmdline.execute('scrapy crawl spider'.split())
