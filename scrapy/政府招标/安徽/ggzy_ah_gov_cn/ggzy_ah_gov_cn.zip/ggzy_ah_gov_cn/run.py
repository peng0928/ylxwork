# -*- coding: utf-8 -*-
# @Date    : 2022-09-09 14:45
# @Author  : chenxuepeng
from scrapy import cmdline

cmdline.execute('scrapy crawl spider'.split())