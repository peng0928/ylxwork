import scrapy, json
from prec_sxzwfw_gov_cn.items import Item
from prec_sxzwfw_gov_cn.data_process import *
from prec_sxzwfw_gov_cn.redis_conn import *


class SpiderSpider(scrapy.Spider):
    name = 'spider'
    start_urls = ['http://prec.sxzwfw.gov.cn/queryContent-jyxx.jspx']

    body = 'title=&channelId=17&origin=&inDates=4000&beginTime=&endTime=&ext='
    host = 'prec.sxzwfw.gov.cn'
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Host': 'prec.sxzwfw.gov.cn',
        'Origin': 'http://prec.sxzwfw.gov.cn',
        'Referer': 'http://prec.sxzwfw.gov.cn/queryContent-jyxx.jspx',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
        }

    def start_requests(self):
        for page in range(1, 10960):
            condition = True
            if page < 2:
                url = self.start_urls[0]
            else:
                url = self.start_urls[0].replace('queryContent', f'queryContent_{str(page)}')
            query = post_link(url, data=self.body, headers=self.headers, rpath="//div[@class='cs_two_content']/a/@href")
            for lurl in query:
                conn = redis_conn()
                result = conn.find_data(value=lurl)
                if result is False:
                    yield scrapy.Request(url=lurl, callback=self.con_parse)
                else:
                    print('已存在:', lurl)
                condition = False
            if condition is False:
                # pass
                break

    def con_parse(self, response):
        item = Item()
        try:
            result = Xpath(response.text)
            title = result.xpath("//p[@class='cs_title_P1']")
            date = result.dpath("//p[@class='cs_title_P3']", rule=None)
            content = result.xpath("//div[@class='div-article2']/table[@class='gycq-table']", filter="script|style")

            file = result.fxpath("//table[@class='gycq-table']//a")
            filename = file[0]
            filelink = file[1]

            item['filename'] = filename
            item['filelink'] = filelink
            content_result = process_content_type(C=content, F=filelink)
            item['host'] = self.host
            item['pageurl'] = response.url
            item['publishdate'] = date
            item['docsubtitle'] = title
            item['doc_content'] = content
            item['contenttype'] = content_result
            # print(item)
            yield item

        except Exception as e:
            print(e)


# 启动
if __name__ == '__main__':
    from scrapy import cmdline
    cmdline.execute(f'scrapy crawl {SpiderSpider.name}'.split())