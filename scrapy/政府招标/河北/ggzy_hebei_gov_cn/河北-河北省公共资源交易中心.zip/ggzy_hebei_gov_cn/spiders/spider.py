import scrapy
from scrapy import cmdline
import requests, json
from ggzy_hebei_gov_cn.data_process import *
from ggzy_hebei_gov_cn.redis_conn import *
from ggzy_hebei_gov_cn.items import Item

class SpiderSpider(scrapy.Spider):
    name = 'spider'
    host = 'ggzy.hebei.gov.cn'
    start_urls = ['http://ggzy.hebei.gov.cn/EpointWebBuilderZx/rest/mygeneraterest/get']
    custom_settings = {
        'LOG_LEVEL': 'INFO',
    }
    # xpath
    headers = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Connection': 'keep-alive',
        'Content-Length': '88',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Host': 'ggzy.hebei.gov.cn',
        'Origin': 'http://ggzy.hebei.gov.cn',
        'Referer': 'http://ggzy.hebei.gov.cn/hbjyzx/jydt/001001/001001001/todayTrading.html',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
        'X-Requested-With': 'XMLHttpRequest',
    }
    pubdate_xpath = "//div[@class='ewb-bar-info']" + "//text()"
    title_xpath = "//h2[@class='ewb-con-h']" + "//text()"
    content_xpath = "//div[@class='ewb-con-p']" + "//text()"

    def start_requests(self):
        for page in range(0,6):
            page = str(page)
            data = f"pageIndex={page}&pageSize=6&projectName=&projectNo=&type=%E4%BB%8A%E6%97%A5%E4%BA%A4%E6%98%93"
            response = requests.post(url=self.start_urls[0], data=data, headers=self.headers)
            response_json = json.loads(response.text)['data']
            condition = True
            for query in response_json:
                GONGGAOGUID = query['GONGGAOGUID']
                infoid = f'infoid={GONGGAOGUID}'
                response = requests.post(url='http://ggzy.hebei.gov.cn/EpointWebBuilderZx/rest/mygeneraterest/getUrlByinfoid',
                                         data=infoid,
                                         headers=self.headers)
                msg = json.loads(response.text)['msg']
                c_url = 'http://ggzy.hebei.gov.cn/hbjyzx' + msg

                conn = redis_conn()
                result = conn.find_data(value=c_url)
                if result is False:
                    yield scrapy.Request(url=c_url, callback=self.con_parse, headers={
                        'Cookie': '_gscu_1921552764=58891282g6v0di88; _gscbrs_1921552764=1; oauthClientId=demoClient; oauthPath=http://172.19.3.38:8080/EpointWebBuilderZw; oauthLoginUrl=http://172.19.3.38:8080/EpointWebBuilderZw/rest/oauth2/authorize?client_id=demoClient&state=a&response_type=code&scope=user&redirect_uri=; oauthLogoutUrl=http://172.19.3.38:8080/EpointWebBuilderZw/rest/oauth2/logout?redirect_uri=; noOauthRefreshToken=adf950b49bbdb03642a3edfc9917f5b3; noOauthAccessToken=41455cb342febef7a332d938ac9af464; _gscs_1921552764=t58907164p30q0v20|pv:2',
                    })
                else:
                    condition = False
            if condition is False:
                break


    def con_parse(self, response):
        item = Item()
        try:
            result = Xpath(response.text)
            title = result.xpath("//h2[@class='ewb-con-h']")
            date = result.dpath("//div[@class='ewb-bar-info']", rule=None)
            content = result.xpath("//div[@class='ewb-con-p']", filter="script|style")

            # filename = response.xpath("").extract() or None
            # filelink = response.xpath("").extract() or None
            # if filelink is not None and filename is not None:
            #     fileurl = ''
            #     filename = '|'.join(filename)
            #     filelink = fileurl + f'|{fileurl}'.join(filelink)
            # item['filename'] = filename
            # item['filelink'] = filelink
            content_result = process_content_type(C=content, F=None)
            item['host'] = self.host
            item['pageurl'] = response.url
            item['publishdate'] = date
            item['docsubtitle'] = title
            item['doc_content'] = content
            item['contenttype'] = content_result
            # print(item)
            yield item

        except Exception as e:
            print(e)

# 启动
if __name__ == '__main__':
    cmdline.execute(f'scrapy crawl {SpiderSpider.name}'.split())
