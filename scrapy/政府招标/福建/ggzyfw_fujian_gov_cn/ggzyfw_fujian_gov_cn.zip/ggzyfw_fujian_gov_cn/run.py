# -*- coding: utf-8 -*-
# @Date    : 2022-10-20 16:26
# @Author  : chenxuepeng
from scrapy import cmdline

cmdline.execute('scrapy crawl spider'.split())