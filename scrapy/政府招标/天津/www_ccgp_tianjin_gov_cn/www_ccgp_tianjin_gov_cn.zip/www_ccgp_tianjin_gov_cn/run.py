# -*- coding: utf-8 -*-
# @Date    : 2022-09-07 09:45
# @Author  : chenxuepeng
from scrapy import cmdline

cmdline.execute('scrapy crawl spider '.split())
