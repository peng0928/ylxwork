# -*- coding: utf-8 -*-
# @Date    : 2022-09-05 10:36
# @Author  : chenxuepeng
import pytesseract, requests
from PIL import Image


def download_img(mode='wb', link=None, img_name=None, path=None):
    img_path = path + img_name
    with open(img_path, mode=mode) as f:
        res = requests.get(url=link)
        print('正在下载:', link)
        f.write(res.content)


def read_pytesseract(path=None):
    im = Image.open(path)
    text = pytesseract.image_to_string(im, lang='chi_sim')
    return text


