import scrapy
from ..data_process import *
from ..redis_conn import *


class JiLinSpider(scrapy.Spider):
    name = 'spider'
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Cache-Control": "max-age=0",
        "Connection": "keep-alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Cookie": "_gscu_1208125908=66171183wvjgob29; _gscbrs_1208125908=1; _gscs_1208125908=t66228251joxb6c14|pv:34",
        "Host": "www.ccgp-jilin.gov.cn",
        "Origin": "http://www.ccgp-jilin.gov.cn",
        "Referer": "http://www.ccgp-jilin.gov.cn/ext/search/morePolicyNews.action",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36"
    }
    host = 'www.ccgp-jilin.gov.cn'
    condition = True
    def start_requests(self):
        urls = ['http://www.ccgp-jilin.gov.cn/ext/search/morePolicyNews.action']
        page = [140, 1500, 6, 300, 600, 100, 400, 4000, 1000, 1500, 3000, 30, 700, 2, 300, 100, 30, 25, 1000, 150, 400, 500]
        ss = '13ef8dce54c85d56233db0672a3e557009abf1f4dd4cef7919e634432f74d0383a706d5f53d84ba10f8299c03769e7995b29f5c79a998c831f99cd39c92f9ef3c16410f04e0cf189572549309482a3c98f8d3c11dcab1956d237ca89286c6601ef6a0a3a8b8f0f164cbe05b96d63b88fe6ad4b3b80e0f25d8ab15c34545c0d90'
        datas = [
            # 市县采购公告
            f'currentPage=1&noticetypeId=1&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 资格预审
            f'currentPage=1&noticetypeId=2&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 公开招标
            f'currentPage=1&noticetypeId=7&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 邀请招标
            f'currentPage=1&noticetypeId=4&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 竞争性谈判
            f'currentPage=1&noticetypeId=5&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 竞争性磋商
            f'currentPage=1&noticetypeId=6&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 单一来源
            f'currentPage=1&noticetypeId=3&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 询价公告
            f'currentPage=1&noticetypeId=9&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 中标公告
            f'currentPage=1&noticetypeId=10&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 成交公告
            f'currentPage=1&noticetypeId=11,12,8&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',# 废标、更正、其他公告
            f'currentPage=1&noticetypeId=13,14&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 合同、验收公告

            # 省级采购公告
            f'currentPage=1&noticetypeId=1&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 资格预审
            f'currentPage=1&noticetypeId=2&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 公开招标
            f'currentPage=1&noticetypeId=7&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 邀请招标
            f'currentPage=1&noticetypeId=4&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 竞争性谈判
            f'currentPage=1&noticetypeId=5&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 竞争性磋商
            f'currentPage=1&noticetypeId=6&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 单一来源
            f'currentPage=1&noticetypeId=3&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 询价公告
            f'currentPage=1&noticetypeId=9&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 中标公告
            f'currentPage=1&noticetypeId=10&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 成交公告
            f'currentPage=1&noticetypeId=11,12,8&categoryId=124&articleId=1&ss={ss}&id=1&pager.pageNumber=1',
            # 废标、更正、其他公告
            f'currentPage=1&noticetypeId=13,14&categoryId=125&articleId=1&ss={ss}&id=1&pager.pageNumber=1',  # 合同、验收公告

        ]
        for data in range(len(datas)):
            for page in range(page[data]):
                if self.condition is True:
                    yield scrapy.Request(url=urls[0], body=datas[data], headers=self.headers, method='POST', callback=self.lparse)
                else:
                    break

    def lparse(self, response):
        conn = redis_conn()
        lresult = response.xpath("//div[@id='list_right']/ul/li/a/@href").getall()
        lurls = url_join(response.url, lresult)
        for lurl in lurls:
            result = conn.find_data(value=lurl)
            if result is False:
                yield scrapy.Request(url=lurl, headers=self.headers, callback=self.cparse)
            else:
                print('已存在:', lurl)
                self.condition = False

    def cparse(self, response):
        item = {}
        title = response.xpath("//h2[@class='sd']//text()").get()
        data_res = Xpath(response.text)
        pudate = data_res.dpath("//h3[@class='wzxq']")

        content = response.text
        content_result = process_content_type(C=content)
        item['host'] = self.host
        item['pageurl'] = response.url
        item['publishdate'] = pudate
        item['docsubtitle'] = title
        item['pagesource'] = content
        item['contenttype'] = content_result
        # print(item)
        yield item