# -*- coding: utf-8 -*-
# @Date    : 2022-09-13 09:35
# @Author  : chenxuepeng
from scrapy import cmdline

cmdline.execute('scrapy crawl spider'.split())