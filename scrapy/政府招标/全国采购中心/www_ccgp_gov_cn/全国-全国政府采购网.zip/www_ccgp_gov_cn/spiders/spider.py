import scrapy, requests
from scrapy import cmdline
from www_ccgp_gov_cn.items import Item
from www_ccgp_gov_cn.data_process import *
from www_ccgp_gov_cn.redis_conn import redis_conn
from lxml import etree

class SpiderSpider(scrapy.Spider):
    name = 'ccgpgovspider'
    custom_settings = {
        'LOG_LEVEL': 'INFO',
        'FEED_EXPORT_ENCODING ': 'utf-8',
        'ITEM_PIPELINES': {
            'www_ccgp_gov_cn.pipelines.Pipeline': 300,
            'crawlab.pipelines.CrawlabMongoPipeline': 888, # 5.0
        }
    }
    host = 'www.ccgp.gov.cn'

    def start_requests(self):
        # 全国政府采购网   全国人大机关采购中心
        start_url = ['http://www.ccgp.gov.cn/cggg/zygg/index.htm', 'http://www.ccgp.gov.cn/cggg/dfgg/index.htm',
                     'http://www.ccgp.gov.cn/qgrd/zhbgg/index.htm', 'http://www.ccgp.gov.cn/qgrd/zbgg/index.htm'
                         ]
        for l in start_url:
                condition = True

                for page in range(0, 25):
                    if page < 1:
                        url = l
                    else:
                        page = str(page)
                        url = l.replace('index', f'index_{page}')

                    resp = requests.get(url=url)
                    tree = etree.HTML(resp.text)
                    data = tree.xpath("//div[@class='main_list']/ul[@class='ulst']/li/a/@href|//ul[@class='c_list_bid']/li/a/@href")
                    for i in data:
                        href = i.replace('./', '/').replace('././', '/')
                        if 'cggg/zygg' in url:
                            lurl = 'http://www.ccgp.gov.cn/cggg/zygg' + href
                        if 'cggg/dfgg' in url:
                            lurl = 'http://www.ccgp.gov.cn/cggg/dfgg' + href
                        if 'qgrd/zbgg' in url or 'qgrd/zhbgg' in url:
                            lurl = 'http://www.ccgp.gov.cn' + href

                        conn = redis_conn()
                        result = conn.find_data(value=lurl)
                        if result is False:
                            yield scrapy.Request(url=lurl, callback=self.con_parse)
                        else:
                            print('已存在', url)
                            condition = False
                    if condition is False:
                        break


    def con_parse(self, response):
        item = Item()
        try:
            result = Xpath(response.text)
            title = result.xpath("//h2[@class='tc']")
            date = result.dpath("//span[@id='pubTime']", rule=None)
            content = result.xpath("//div[@class='vT_detail_main']/div[@class='vT_detail_content w760c']|//div[@class='vT_detail_main']/div[@class='table']|//div[@class='vF_detail_content']",
                                   filter="td[@class='bid_attachtab_content']|script|style")
            content_result = process_content_type(C=content)

            filename = response.xpath("//a[@class='bizDownload']/text()").extract() or None
            filelink = response.xpath("//a[@class='bizDownload']/@id").extract() or None
            if filelink is not None and filename is not None:
                fileurl = 'http://download.ccgp.gov.cn/oss/download?uuid='
                filename = '|'.join(filename)
                filelink = fileurl + f'|{fileurl}'.join(filelink)
            item['host'] = self.host
            item['pageurl'] = response.url
            item['publishdate'] = date
            item['docsubtitle'] = title
            item['doc_content'] = content
            item['contenttype'] = content_result
            item['filename'] = filename
            item['filelink'] = filelink
            yield item
            # print(item)

        except Exception as e:
            print(e)


if __name__ == '__main__':
    try:
        cmdline.execute(f"scrapy crawl {SpiderSpider.name}".split())
    except:
        print('sb')