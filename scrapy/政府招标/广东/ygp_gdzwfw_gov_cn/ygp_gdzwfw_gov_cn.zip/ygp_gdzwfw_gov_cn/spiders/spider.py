# area 广东省公共资源交易平台
# https://www.gdzwfw.gov.cn/ggzy/gdyzwzh/
import scrapy, pymysql, time
from ygp_gdzwfw_gov_cn.redis_conn import redis_conn
from ygp_gdzwfw_gov_cn.data_process import *
from ygp_gdzwfw_gov_cn.items import Item
from ygp_gdzwfw_gov_cn.settings import *

class SpiderSpider(scrapy.Spider):
    name = 'spider'
    host = 'ygp.gdzwfw.gov.cn'
    custom_settings = {
        'ITEM_PIPELINES': {
           f'{BOT_NAME}.pipelines.Pipeline': 300,
            # 'crawlab.pipelines.CrawlabMongoPipeline': 888, # 5.0
        },
        'LOG_LEVEL': 'INFO',

        # 允许状态码
        # 'HTTPERROR_ALLOWED_CODES': [403, 404, 400],
        'COOKIES_ENABLED': False,
        # 'CONCURRENT_REQUESTS_PER_DOMAIN': 16
        # 'CONCURRENT_REQUESTS_PER_IP': 16
        'DOWNLOAD_DELAY': 0.5
        # 'CONCURRENT_REQUESTS': 32
    }
    headers = {
'Accept': 'application/json, text/plain, */*',
'Accept-Encoding': 'gzip, deflate, br',
'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
'Connection': 'keep-alive',
'Content-Type': 'application/json',
'Cookie': '_horizon_sid=de566c83-8c7f-4f77-bab0-be1336427c44; _horizon_uid=f6483a48-bdd9-4247-87be-b42ffa51b9cf',
'Host': 'ygp.gdzwfw.gov.cn',
'Origin': 'https://ygp.gdzwfw.gov.cn',
'Referer': 'https://ygp.gdzwfw.gov.cn/',
'Sec-Fetch-Dest': 'empty',
'Sec-Fetch-Mode': 'cors',
'Sec-Fetch-Site': 'same-origin',
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
'X-Dgi-Req-App': 'ggzy-portal',
'X-Dgi-Req-Nonce': '2eDQEsqtPco4aTiR',
'X-Dgi-Req-Signature': 'b9fd024c21d65791c4eb933fd2f35acf1e709d54c1632fb1081817609ed49fbb',
'X-Dgi-Req-Timestamp': '1659573494554',
'sec-ch-ua': '".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"',
'sec-ch-ua-mobile': '?0',
'sec-ch-ua-platform': '"Windows"',
        }
    ###########读取redis数据库爬取############
    def start_requests(self):
        conn = redis_conn()
        result = conn.get_data(field=redis_name)  # '政府招标:
        for query in result:
            url = str(query, encoding='utf-8')
            yield scrapy.Request(url=url, callback=self.cparse)

    def cparse(self, res):
        item = Item()
        try:
            data = res.json()['data'][0]
            result = Xpath(data['noticeContent'])
            title = data['noticeName']
            date = data['noticeSendTime']
            content = result.xpath("", filter=None)
            content_result = process_content_type(C=content)

            item['host'] = self.host
            item['pageurl'] = res.url
            item['docsubtitle'] = title
            item['publishdate'] = date
            item['contenttype'] = content_result
            item['doc_content'] = content
            yield item
            # print(item)
        except Exception as e:
            print(e)

    
    # def start_requests(self):
    #     start_url = 'https://ygp.gdzwfw.gov.cn/ggzy-portal/search/v1/items' # 交易广告
    #     for page in range (9994):
    #         data1 = '{"type":"trading-type","publishStartTime":"","publishEndTime":"","siteCode":"44","secondType":"A","projectType":"","thirdType":"","dateType":"","total":99894,'
    #         data2 = f'"pageNo":{str(page)},'
    #         data3 = '"pageSize":10,"openConvert":true}'
    #         data = data1 + data2 + data3
    #         yield scrapy.Request(url=start_url, method='POST', headers=self.headers, body=data, callback=self.dparse)
    #
    # def dparse(self, res):
    #     try:
    #         r = redis_conn()
    #         json_res = res.json()['data']['pageData']
    #         for query in json_res:
    #             projectCode = f'https://ygp.gdzwfw.gov.cn/ggzy-portal/center/apis/trading-notice/detail?tradingType=A&projectCode=' + query['projectCode'] +'&tradingProcess=A02&siteCode=440300'
    #             r.set_add(self.redis_name, projectCode)
    #
    #     except Exception as e:
    #         print(e)


############## 启动 ##############
if __name__ == '__main__':
    from scrapy import cmdline

    cmdline.execute(f'scrapy crawl {SpiderSpider.name}'.split())
