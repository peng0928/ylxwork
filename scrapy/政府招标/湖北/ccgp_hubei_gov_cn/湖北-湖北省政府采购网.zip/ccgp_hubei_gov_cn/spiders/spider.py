import scrapy, json
from ccgp_hubei_gov_cn.redis_conn import redis_conn
from ccgp_hubei_gov_cn.data_process import *
from ccgp_hubei_gov_cn.items import Item

class SpiderSpider(scrapy.Spider):
    name = 'spider'
    host = 'ccgp-hubei.gov.cn'

    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Cookie': 'JSESSIONID=5FBF4E8A8A8D64C1EFF278D50AF5C435; JSESSIONID=31FCEBCE3B0A108DA537289DD8570199',
        'Host': 'www.ccgp-hubei.gov.cn:9040',
        'Origin': 'http://www.ccgp-hubei.gov.cn:9040',
        'Referer': 'http://www.ccgp-hubei.gov.cn:9040/quSer/search',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
    }
    start_urls = [
        # 省级公告-招标(采购)公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/pzbgg/index_1.html',
        # 省级公告-中标(成交)公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/pzhbgg/index_1.html',
        # 省级公告-更正公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/pgzgg/index_1.html',
        # 省级公告-终止公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/pfbgg/index_1.html',
        # 市县公告-招标(采购)公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/czbgg/index_1.html',
        # 市县公告-中标(成交)公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/czhbgg/index_1.html',
        # 市县公告-更正公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/cgzgg/index_1.html',
        # 市县公告-终止公告
        'http://www.ccgp-hubei.gov.cn/notice/cggg/cfbgg/index_1.html',]
    start_indexs = [5, 8, 1, 1, 36, 42, 11, 4]

    def start_requests(self):
        for i in range(8):
            condition = True
            for page in range(1,self.start_indexs[i]+1):
                url = self.start_urls[i].replace('index_1', f'index_{page}')
                query = get_link(url=url, rpath="//div[@class='news-list list-page']//li/a/@href")
                for lurl in query:
                    lurl = 'http://www.ccgp-hubei.gov.cn' + lurl
                    conn = redis_conn()
                    result = conn.find_data(value=lurl)
                    if result is False:
                        yield scrapy.Request(url=lurl, callback=self.con_parse)
                    else:
                        print('已存在:', lurl)
                    condition = False
                if condition is False:
                    break

    def con_parse(self, response):
        item = Item()
        result = Xpath(response.text)
        title = result.xpath("//div[@class='art_con']//h2")
        date = result.dpath("//div[@class='art_con']/div[1]/div", rule=None)
        content = result.xpath("//div[@class='art_con']", filter="script|style")
        content_result = process_content_type(C=content)

        item['host'] = self.host
        item['pageurl'] = response.url
        item['docsubtitle'] = title
        item['publishdate'] = date
        item['contenttype'] = content_result
        item['doc_content'] = content
        # print(item)
        yield item


############################ 启动
if __name__ == '__main__':
    from scrapy import cmdline
    cmdline.execute(f'scrapy crawl {SpiderSpider.name}'.split())
