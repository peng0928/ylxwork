# -*- coding: utf-8 -*-
# @Date    : 2022-10-20 09:51
# @Author  : chenxuepeng

if __name__ == '__main__':
    from scrapy import cmdline

    cmdline.execute('scrapy crawl spider'.split())