# http://ccgp-jiangxi.gov.cn/web/
import scrapy, pymysql, time
from jxsggzy_cn.redis_conn import redis_conn
from jxsggzy_cn.data_process import *
from jxsggzy_cn.items import Item
from jxsggzy_cn.settings import *


class SpiderSpider(scrapy.Spider):
    name = 'spider'
    host = 'jxsggzy.cn'
    custom_settings = {
        'ITEM_PIPELINES': {
            f'{BOT_NAME}.pipelines.Pipeline': 300,
            'crawlab.pipelines.CrawlabMongoPipeline': 888, # 5.0
        },
        'LOG_LEVEL': 'INFO',
        'DOWNLOADER_MIDDLEWARES': {
           f'{BOT_NAME}.ProxyMiddlewares.UserAgentDownloadMiddleware': 300,
            f'{BOT_NAME}.ProxyMiddlewares.ProxyMiddleware': 300,
        },

        # 允许状态码
        'HTTPERROR_ALLOWED_CODES': [403, 404, 400],
        # 'COOKIES_ENABLED': False,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 16,
        'CONCURRENT_REQUESTS_PER_IP': 16,
        'DOWNLOAD_DELAY': 1,
        'CONCURRENT_REQUESTS': 32,
    }

    start_pages = [9047, 1983, 9805]

    def start_requests(self):
        for i in range(3):
            condition = True
            for page in range(1, self.start_pages[i]+1):
                url = [
                    # 采购公告
                    f'https://jxsggzy.cn/web/jyxx/002006/002006001/{page}.html',
                    # 变更公告
                    f'https://jxsggzy.cn/web/jyxx/002006/002006002/{page}.html',
                    # 结果公示
                    f'https://jxsggzy.cn/web/jyxx/002006/002006004/{page}.html',
                ]

                query = get_link(url[i], "//a[@class='ewb-list-name']/@href")
                for item in query:
                    lurl = 'https://jxsggzy.cn' + item
                    conn = redis_conn()
                    result = conn.find_data(value=lurl)
                    if result is False:
                        yield scrapy.Request(url=lurl, callback=self.con_parse)
                    else:
                        print('已存在:', lurl)
                    condition = False
                if condition is False:
                    break

    def con_parse(self, response):
        item = Item()
        try:
            result = Xpath(response.text)
            title = result.xpath("//div[@class='article-info']/h1")
            date = result.dpath("//p[@class='infotime']", rule=None)
            content = result.xpath("//div[@class='article-info']/div[@class='con']", filter="script|style")

            file = result.fxpath("//div[@class='con attach']/a", rule='https://jxsggzy.cn')
            filename = file[0]
            filelink = file[1]

            item['filename'] = filename
            item['filelink'] = filelink
            content_result = process_content_type(C=content, F=filelink)
            item['host'] = self.host
            item['pageurl'] = response.url
            item['publishdate'] = date
            item['docsubtitle'] = title
            item['doc_content'] = content
            item['contenttype'] = content_result
            # print(item)
            yield item

        except Exception as e:
            print(e)


############## 启动 ##############
if __name__ == '__main__':
    from scrapy import cmdline

    cmdline.execute(f'scrapy crawl {SpiderSpider.name}'.split())
